function getChatId(source) {
  if (source.type === 'user') {
    return source.userId;
  }

  if (source.type === 'group') {
    return source.groupId;
  }

  if (source.type === 'room') {
    return source.roomId;
  }
  return null;
}

module.exports = getChatId;