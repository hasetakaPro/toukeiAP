'use strict';

const line = require('@line/bot-sdk');
const express = require('express');
const apiai = require('apiai');
const { Pool } = require('pg');
require('date-utils');

// create LINE SDK config from env variables
const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET,
};

// get Dialogflow token from env variables
const apiaiToken = process.env.APIAI_TOKEN;

let apiaiOptions = {
  language: process.env.APIAI_LANG,
  requestSource: "line"
};

// create Dialogflow client
const dfClient = apiai(apiaiToken,apiaiOptions);


//postgers connection definition
const connectionString = 'postgres://kwfjkpbufdkhtb:d351bcbc1472a09afb6b7f72f29bc9e7b62d530d037b799eaaac224c86076561@ec2-50-19-232-205.compute-1.amazonaws.com:5432/d3200ebjs8454f?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory';

// create LINE SDK client
const client = new line.Client(config);

// create Express app
// about Express itself: https://expressjs.com/
const app = express();

// register a webhook handler with middleware
// about the middleware, please refer to doc
app.post('/webhook', line.middleware(config), (req, res) => {
  Promise
    .all(req.body.events.map(handleEvent))
    .then((result) => res.json(result));
});

// event handler
function handleEvent(event) {
  if (event.type !== 'message' || event.message.type !== 'text') {
    // ignore non-text-message event
    return Promise.resolve(null);
  }
  const pool = new Pool({
    connectionString: connectionString,
  });
  var DATE = require("./index3.js");
  var dt = new Date();
  var dt1 = new DATE(event.message.text);
  if (event.message.text == "明日")　dt.setDate(dt.getDate()+1);
  
  if (event.message.text == "前月"){
    dt.setMonth(dt.getMonth()-1);
    var query = "SELECT A.ymd, CASE WHEN B.name IS NOT NULL THEN B.name ELSE 'NA' END AS name FROM ( (SELECT * FROM public.ymdmst  WHERE to_char(ymd,'YYYYMM') =  \'" + dt.toFormat("YYYYMM") + "\') AS A LEFT OUTER JOIN public.mobilephone AS B ON A.ymd = B.date) order by 1,2";
  }
  else　if(event.message.text != "拡張中"){
    var query = "SELECT A.ymd, CASE WHEN B.name IS NOT NULL THEN B.name ELSE 'NA' END AS name FROM ( (SELECT * FROM public.ymdmst WHERE ymd between \'" + dt.toFormat("YYYY-MM-DD") + "\' AND \'" + dt1.toFormat("YYYY-MM-DD") +"\') AS A LEFT OUTER JOIN public.mobilephone AS B ON A.ymd = B.date) order by 1,2";
  }
  else{
    var result_psql = "拡張中だよ！！"
    const reply = { type: 'text', text: result_psql };
    return client.replyMessage(event.replyToken, reply); 
  }
  
  pool.query(query, (err, res) => {

    if(res == null){
      var result_psql = "その日の保守携帯担当は決まっていません。"
      const reply = { type: 'text', text: result_psql };
      // use reply API
      // console.log(reply)
      return client.replyMessage(event.replyToken, reply);  
    }
    else{
      //1day
      var WeekChars = [ "日", "月", "火", "水", "木", "金", "土" ];
      if(res.rowCount == 1){
        var result_psql = res.rows[0].ymd.toFormat("MM/DD") + "(" + WeekChars[res.rows[0].ymd.getDay()] + ")  "  + res.rows[0].name ;      
      }else{ //1day以上
        var result_psql = ""
        for(var i =0;i<res.rowCount;i++){
          if (i == res.rowCount -1) {
            result_psql = result_psql + res.rows[i].ymd.toFormat("MM/DD") + "(" + WeekChars[res.rows[i].ymd.getDay()] + ")  "  + res.rows[i].name
          }else{
            result_psql = result_psql + res.rows[i].ymd.toFormat("MM/DD") + "(" + WeekChars[res.rows[i].ymd.getDay()] + ")  "  + res.rows[i].name + "\n"
          } 
        }    
      }
      const reply = { type: 'text', text: result_psql };
      // use reply API
      console.log(reply)
      return client.replyMessage(event.replyToken, reply);   
    }
    pool.end()
  })
}


// listen on port
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`listening on ${port}`);
});

