
require('date-utils');

const { Pool } = require('pg')
const connectionString = 'postgres://kwfjkpbufdkhtb:d351bcbc1472a09afb6b7f72f29bc9e7b62d530d037b799eaaac224c86076561@ec2-50-19-232-205.compute-1.amazonaws.com:5432/d3200ebjs8454f?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory'
const pool = new Pool({
  connectionString: connectionString,
})


var dt1 = new Date();

//var query = "SELECT A.ymd, CASE WHEN B.name IS NOT NULL THEN B.name ELSE 'NA' END AS name FROM ( (SELECT * FROM public.ymdmst WHERE ymd between '2018-05-01' AND '2018-5-31') AS A LEFT OUTER JOIN public.mobilephone AS B ON A.ymd = B.date)";
var query  ="INSERT INTO public.mobilephone  values(\'" + dt1.toFormat("YYYY-MM-DD") + "\',\'t\')"; 
var query3 ="UPDATE public.mobilephone set name = \'s\' where date = \'" +dt1.toFormat("YYYY-MM-DD") + "\'";
var query2 ="SELECT * FROM public.mobilephone";
console.log(query4);

pool.query(query4, (err, res) => {
  console.log(err);
  if (err) {
    console.log("bad query");
  }
  else{
    console.log("recored inserted");
  }
  pool.end()
})

