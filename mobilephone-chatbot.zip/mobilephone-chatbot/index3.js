
require('date-utils');

var DATE =function(text){
    //this.text = text;
    var dt = new Date();

    switch(text){
        case "今日":
            break;
        case "明日":
            dt.setDate(dt.getDate()+1);
            break;
        case "一週間":
            dt.setDate(dt.getDate()+6);
            break;
        case "一か月":
            dt.setMonth(dt.getMonth()+1);
            dt.setDate(dt.getDate()-1);
            break;
    }
    dt.toFormat("YYYY-MM-DD");
    return dt;
}

module.exports = DATE;

