var fs = require('fs');
var copyFrom = require('pg-copy-streams').from;
require('date-utils');
const { Pool } = require('pg')
const connectionString = 'postgres://kwfjkpbufdkhtb:d351bcbc1472a09afb6b7f72f29bc9e7b62d530d037b799eaaac224c86076561@ec2-50-19-232-205.compute-1.amazonaws.com:5432/d3200ebjs8454f?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory'
const pool = new Pool({
  connectionString: connectionString,
})

pool.connect(function(err, client, done) {
  var stream = client.query(copyFrom('COPY public.mobilephone FROM STDIN'));
  var fileStream = fs.createReadStream('data.txt')
  fileStream.on('error', done);
  fileStream.pipe(stream).on('finish', done).on('error', done);
});